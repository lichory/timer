//
//  View.m
//  timer
//
//  Created by apple on 15/11/23.
//  Copyright © 2015年 apple. All rights reserved.
//

#import "View.h"
#import "NSTimer+Support.h"
@implementation View

- (void)dealloc {
    
    [timer invalidate];
}

- (instancetype)initWithFrame:(CGRect)frame {
    
    if (self = [super initWithFrame:frame]) {
        
        
        self.backgroundColor = [UIColor redColor];
        __weak typeof(self)blockSelf = self;
        timer = [NSTimer wx_scheduledTimerWithTimeInterval:1 block:^{
            [blockSelf timerClick];
        } repeats:YES];
        [[NSRunLoop mainRunLoop]addTimer:timer forMode:NSRunLoopCommonModes];
    }
    return self;
}

- (void)timerClick {
    
    NSLog(@"123123");
}

@end
