//
//  NSTimer+Support.m
//  timer
//
//  Created by apple on 15/11/23.
//  Copyright © 2015年 apple. All rights reserved.
//

#import "NSTimer+Support.h"

@implementation NSTimer (Support)

+ (NSTimer *)wx_scheduledTimerWithTimeInterval:(NSTimeInterval)interval
                                         block:(void(^)())block
                                       repeats:(BOOL)repeat {
    
    // 传入的 self 其实就是 NSTimer ，是一个类对象 （和实例对象区分开）
    return [self scheduledTimerWithTimeInterval:interval target:self selector:@selector(support_blockInvoke:) userInfo:[block copy] repeats:YES];
}

+ (void)support_blockInvoke:(NSTimer *)timer {
    void(^block)() = timer.userInfo;
    if (block) {
        block();
    }
}


@end
